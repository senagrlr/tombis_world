
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../l10n/app_localizations.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../core/services/notification_startup_service.dart';
import 'app_router.dart';

class TombisWorldApp extends ConsumerStatefulWidget {
  const TombisWorldApp({super.key});

  @override
  ConsumerState<TombisWorldApp> createState() => _TombisWorldAppState();
}

class _TombisWorldAppState extends ConsumerState<TombisWorldApp> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      NotificationStartupService.initialize(ref);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        systemNavigationBarColor: AppColors.background,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarContrastEnforced: false,
      ),
      child: MaterialApp.router(
        debugShowCheckedModeBanner: false,

        onGenerateTitle: (context) =>
        AppLocalizations.of(context).appTitle,

        supportedLocales: AppLocalizations.supportedLocales,

        localizationsDelegates: const [
          AppLocalizations.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
        ],

        theme: AppTheme.light,
        routerConfig: appRouter,

        builder: (context, child) {
          return ColoredBox(
            color: AppColors.background,
            child: child ?? const SizedBox.shrink(),
          );
        },
      ),
    );
  }
}
