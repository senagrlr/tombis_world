
class NotificationMessages {
  NotificationMessages._();

  static const String title = "Tombi's World";

  static const List<String> messages = [
    "Tombi is waiting for you! 🐱",
    "Let's add some color to your day! 🎨",
    "It's coloring time with Tombi! 💖",
    "Ready for a colorful adventure? 🌈",
    "Let your imagination shine! ✨",
    "A lovely day with Tombi awaits! 🐱",
    "What's your favorite color? 🎨",
    "How about coloring something new today? 💕",
    "Come have fun with Tombi! 🌸",
    "Get your colors ready! Tombi is waiting! 🖌️",
    "How about a little coloring break? 💛",
    "Today's coloring page is waiting! 🌈",
    "Explore a world of colors with Tombi! ✨",
    "Let's color together! 🎨",
    "Which colors will you choose today? 🐱",
    "Show your creativity with Tombi! 💖",
    "A colorful world is waiting for you! 🌷",
    "Ready for a new coloring adventure? 🖌️",
    "It's time to relax and color with Tombi! 💕",
    "Let's make the world a little brighter! 🌈",
  ];
}
